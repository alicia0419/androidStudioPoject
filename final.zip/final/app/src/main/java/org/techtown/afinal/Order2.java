package org.techtown.afinal;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DecimalFormat;

public class Order2 extends AppCompatActivity {

    ImageView image;
    TextView textView9, textView10, textView11, textView16, textView28;

    Intent intent;

    private Button button13, button14, button15;

    private int count = 0;
    public int mTotalPrice = 0;
    int price = 0;
    int i = 0;

    private CheckBox checkBox14, checkBox15, checkBox16, checkBox17, checkBox18, checkBox19,
                     checkBox20, checkBox21, checkBox22, checkBox23;

    FirebaseDatabase database;
    DatabaseReference reference;

    Item2 item2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.order_2);

        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        reference = database.getInstance().getReference().child("order");
        item2 = new Item2();

        String HOT = "HOT";
        String ICED = "ICED";
        String small = "small(작은)  -300원";
        String regular = "regular(평균)";
        String tall = "tall(큰)  +500원";
        String cup1 = "매장 컵";
        String cup2 = "개인 텀블러";
        String cup3 = "일회용 컵";
        String option8 = "매장";
        String option9 = "포장";

        DecimalFormat myFormatter = new DecimalFormat("###,###");
        String formattedStringformat = myFormatter.format(mTotalPrice);

        button13 = findViewById(R.id.button13);
        button14 = findViewById(R.id.button14);
        button15 = findViewById(R.id.button15);

        textView16 = findViewById(R.id.textView16);

        checkBox14 = findViewById(R.id.checkBox14);
        checkBox15 = findViewById(R.id.checkBox15);
        checkBox16 = findViewById(R.id.checkBox16);
        checkBox17 = findViewById(R.id.checkBox17);
        checkBox18 = findViewById(R.id.checkBox18);
        checkBox19 = findViewById(R.id.checkBox19);
        checkBox20 = findViewById(R.id.checkBox20);
        checkBox21 = findViewById(R.id.checkBox21);
        checkBox22 = findViewById(R.id.checkBox22);
        checkBox23 = findViewById(R.id.checkBox23);

        checkBox14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkBox14.isChecked()) {
                    item2.setOption1(HOT);
                }
            }
        });

        checkBox15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkBox15.isChecked()) {
                    item2.setOption1(ICED);
                }
            }
        });

        checkBox16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkBox16.isChecked()) {
                    mTotalPrice = mTotalPrice - 300;
                    textView16.setText("가격 : " + myFormatter.format(mTotalPrice) + "원");

                    item2.setSize(small);
                    item2.setCount(count);
                    item2.setPrice(mTotalPrice);

                } else {
                    mTotalPrice = mTotalPrice + 300;
                    textView16.setText("가격 : " + myFormatter.format(mTotalPrice) + "원");

                    item2.setSize(small);
                    item2.setCount(count);
                    item2.setPrice(mTotalPrice);
                }
                reference.child(item2.name).setValue(item2);
            }
        });

        checkBox17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkBox17.isChecked()) {
                    mTotalPrice =  mTotalPrice;

                    item2.setSize(regular);
                    item2.setPrice(mTotalPrice);
                }
                reference.child(item2.name).setValue(item2);
            }
        });

        checkBox18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkBox18.isChecked()) {
                    mTotalPrice = mTotalPrice + 500;
                    textView16.setText("가격 : " + myFormatter.format(mTotalPrice) + "원");

                    item2.setSize(tall);
                    item2.setCount(count);
                    item2.setPrice(mTotalPrice);

                } else {
                    mTotalPrice = mTotalPrice - 500;
                    textView16.setText("가격 : " + myFormatter.format(mTotalPrice) + "원");

                    item2.setSize(tall);
                    item2.setCount(count);
                    item2.setPrice(mTotalPrice);
                }
                reference.child(item2.name).setValue(item2);
            }
        });

        checkBox19.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkBox19.isChecked()) {
                    item2.setCup(cup1);
                }
                reference.child(item2.name).setValue(item2);
            }
        });

        checkBox20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkBox20.isChecked()) {
                    item2.setCup(cup2);
                }
                reference.child(item2.name).setValue(item2);
            }
        });

        checkBox21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkBox21.isChecked()) {
                    item2.setCup(cup3);
                }
                reference.child(item2.name).setValue(item2);
            }
        });

        checkBox22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkBox22.isChecked()) {
                    item2.setOption3(option8);
                }
                reference.child(item2.name).setValue(item2);
            }
        });

        checkBox23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkBox23.isChecked()) {
                    item2.setOption3(option9);
                }
                reference.child(item2.name).setValue(item2);
            }
        });


        button13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count++;
                button14.setText(count+"");

                mTotalPrice = price * count;
                textView16.setText("가격 : " + myFormatter.format(mTotalPrice)  + "원" );

                item2.setCount(count);
                item2.setPrice(mTotalPrice);
            }
        });

        button15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(count>0) {
                    count--;
                    button14.setText(count+"");

                    mTotalPrice = price * count;
                    textView16.setText("가격 : " + myFormatter.format(mTotalPrice)  + "원" );

                    item2.setCount(count);
                    item2.setPrice(mTotalPrice);
                }
            }
        });

        image = findViewById(R.id.imageView9);
        textView9 = findViewById(R.id.textView9);
        textView10 = findViewById(R.id.textView10);
        textView11 = findViewById(R.id.textView11);
        textView28 = findViewById(R.id.textView28);

        Intent intent = getIntent();

        image.setImageResource(intent.getIntExtra("image",0));
        item2.setImage(String.valueOf(image));
        reference.child("image");

        String name = getIntent().getStringExtra("name");
        String eng_name = getIntent().getStringExtra("engname");
        item2.setName(name);
        item2.setEng_name(eng_name);
        reference.child("name");
        reference.child("eng_name");

        textView9.setText(name);
        textView10.setText(eng_name);
        textView11.setText(intent.getStringExtra("info"));
        textView28.setText(intent.getStringExtra("price"));
        mTotalPrice = getIntent().getIntExtra("price2", 0);
        price = getIntent().getIntExtra("price2", 0);

    }
}
