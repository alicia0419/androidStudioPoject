package org.techtown.afinal;

import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

public class DAOItem3 {

    private DatabaseReference databaseReference;

    DAOItem3() {
        FirebaseDatabase db = FirebaseDatabase.getInstance();
        databaseReference = db.getReference(Item3.class.getSimpleName());
    }

    // 등록
    public Task<Void> add(Item3 item3) {
        return databaseReference.push().setValue(item3);
    }

    //조회
    public Query get() {
        return databaseReference;

    }

}
