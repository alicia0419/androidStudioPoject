package org.techtown.afinal;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class pay extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pay);

        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        CardView id1 = findViewById(R.id.id1);
        CardView id2 = findViewById(R.id.id2);

        Button button26 = findViewById(R.id.button26);
        Button button29 = findViewById(R.id.button29);

        id1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.naver.com"));
                startActivity(intent);
                // 화면 전환하는 코드  intent는 그대로 이지만 Uri.parse를 이용해서 전환해야 한다.
                // 또한 textView 대신에 그 자리에 버튼을 넣어주어 imageButten 말고 버튼을 넣어서 전환했다.
            }
        });


        button26.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.naver.com"));
                startActivity(intent);
                // 화면 전환하는 코드  intent는 그대로 이지만 Uri.parse를 이용해서 전환해야 한다.
                // 또한 textView 대신에 그 자리에 버튼을 넣어주어 imageButten 말고 버튼을 넣어서 전환했다.
            }
        });

        id2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.kakaopay.com"));
                startActivity(intent);
            }
        });

        button29.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.kakaopay.com"));
                startActivity(intent);
            }
        });
    }
}