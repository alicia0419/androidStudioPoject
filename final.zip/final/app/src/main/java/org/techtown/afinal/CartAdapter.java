package org.techtown.afinal;

import android.content.Context;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.ViewHolder> {

    private static final String Tag = "RecyclerView";
    private Context context;
    private ArrayList<Item3> item3ArrayList;

    public CartAdapter(Context context, ArrayList<Item3> item3ArrayList) {
        this.context = context;
        this.item3ArrayList = item3ArrayList;
    }

    @NonNull
    @Override
    public CartAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_item, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.textView.setText(item3ArrayList.get(position).getName());
        holder.textView3.setText(item3ArrayList.get(position).getOption1());
        holder.textView6.setText(item3ArrayList.get(position).getSize());
        holder.textView8.setText(item3ArrayList.get(position).getCup());
        holder.textView10.setText(item3ArrayList.get(position).getOption2());
        holder.textView12.setText(item3ArrayList.get(position).getOption3());
        holder.textView13.setText(item3ArrayList.get(position).getPrice());
        holder.textView17.setText(item3ArrayList.get(position).getEng_name());
        holder.button2.setText(item3ArrayList.get(position).getCount());


        Glide.with(context)
                .load(item3ArrayList.get(position).getImage())
                .into(holder.image2);


    }

    @Override
    public int getItemCount() {
        return item3ArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView image2;
        TextView textView, textView3, textView6, textView8, textView10, textView12, textView13, textView17;
        Button button, button2, button3;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            image2 = (ImageView) itemView.findViewById(R.id.image2);

            textView = (TextView) itemView.findViewById(R.id.textView);
            textView3 = (TextView) itemView.findViewById(R.id.textView3);
            textView6 = (TextView) itemView.findViewById(R.id.textView6);
            textView8 = (TextView) itemView.findViewById(R.id.textView8);
            textView10 = (TextView) itemView.findViewById(R.id.textView10);
            textView12 = (TextView) itemView.findViewById(R.id.textView12);
            textView13 = (TextView) itemView.findViewById(R.id.textView13);
            textView17 = (TextView) itemView.findViewById(R.id.textView17);

            button = (Button) itemView.findViewById(R.id.button);
            button2 = (Button) itemView.findViewById(R.id.button2);
            button3 = (Button) itemView.findViewById(R.id.button3);

        }
    }
}
