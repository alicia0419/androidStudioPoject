package org.techtown.afinal;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Dialog dialog01;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        Button button2 = findViewById(R.id.button2); // 카메라 버튼에 객체 생성
        button2.setOnClickListener(new View.OnClickListener() { // 클릭리스너 장착
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(), Product.class);
                startActivity(intent);
            }
        });


        dialog01 = new Dialog(MainActivity.this);
        dialog01.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog01.setContentView(R.layout.popup);

        findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                showDialog();
            }
        });







    }

    private void showDialog() {

        dialog01.show();

        Button button5 = dialog01.findViewById(R.id.button5);

        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(), Product.class);
                startActivity(intent);
            }
        });
    }

}