package org.techtown.afinal;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DecimalFormat;

public class Order1 extends AppCompatActivity {

    ImageView image;

    TextView textView6, textView7, textView8, textView27, textView29;

    Intent intent;

    private Button button7, button8, button9, button10, button11;

    public int count = 0;

    private CheckBox checkBox, checkBox2, checkBox3, checkBox4, checkBox5, checkBox6, checkBox7,
                     checkBox8, checkBox9, checkBox10, checkBox11, checkBox12, checkBox13;

    FirebaseDatabase database;
    DatabaseReference reference;


    Item2 item2;

    int i = 0;
    int mTotalPrice = 0;
    int price = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.order_1);

        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        reference = database.getInstance().getReference().child("order");
        item2 = new Item2();

        String HOT = "HOT";
        String ICED = "ICED";
        String small = "small(작은)  -300원";
        String regular = "regular(평균)";
        String tall = "tall(큰)  +500원";
        String cup1 = "매장 컵";
        String cup2 = "개인 텀블러";
        String cup3 = "일회용 컵";
        String option1 = "휘핑크림 추가  +1,000원";
        String option2 = "샷 추가  +500원";
        String option3 = "설탕(시럽) 추가  +500원";
        String option4 = "휘핑크림 추가  +1,000원,  샷 추가  +500원";
        String option5 = "휘핑크림 추가  +1,000원,  설탕(시럽) 추가  +500원";
        String option6 = "샷 추가  +500원,  설탕(시럽) 추가  +500원";
        String option7 = "휘핑크림 추가  +1,000원, 샷 추가  +500원, 설탕(시럽) 추가  +500원";
        String option8 = "매장";
        String option9 = "포장";

        DecimalFormat myFormatter = new DecimalFormat("###,###");
        String formatStringformat = myFormatter.format(mTotalPrice);

        button7 = findViewById(R.id.button7);
        button8 = findViewById(R.id.button8);
        button9 = findViewById(R.id.button9);

        textView29 = findViewById(R.id.textView29);

        checkBox = findViewById(R.id.checkBox);
        checkBox2 = findViewById(R.id.checkBox2);
        checkBox3 = findViewById(R.id.checkBox3);
        checkBox4 = findViewById(R.id.checkBox4);
        checkBox5 = findViewById(R.id.checkBox5);
        checkBox6 = findViewById(R.id.checkBox6);
        checkBox7 = findViewById(R.id.checkBox7);
        checkBox8 = findViewById(R.id.checkBox8);
        checkBox9 = findViewById(R.id.checkBox9);
        checkBox10 = findViewById(R.id.checkBox10);
        checkBox11 = findViewById(R.id.checkBox11);
        checkBox12 = findViewById(R.id.checkBox12);
        checkBox13 = findViewById(R.id.checkBox13);

        checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkBox.isChecked()) {
                    item2.setOption1(HOT);
                }
            }
        });

        checkBox2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (checkBox2.isChecked()) {
                    item2.setOption1(ICED);
                }
            }
        });

        checkBox3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkBox3.isChecked()) {
                    mTotalPrice = mTotalPrice - 300;
                    textView29.setText("가격 : " + myFormatter.format(mTotalPrice) + "원");

                    item2.setSize(small);
                    item2.setPrice(mTotalPrice);


                } else {
                    mTotalPrice = mTotalPrice + 300;
                    textView29.setText("가격 : " + myFormatter.format(mTotalPrice) + "원");

                    item2.setSize(small);
                    item2.setPrice(mTotalPrice);
                }
                reference.child(item2.name).setValue(item2);
            }
        });

        checkBox4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkBox4.isChecked()) {
                    mTotalPrice = mTotalPrice;

                    item2.setSize(regular);
                    item2.setPrice(mTotalPrice);
                }
                reference.child(item2.name).setValue(item2);
            }
        });

        checkBox5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkBox5.isChecked()) {
                    mTotalPrice = mTotalPrice + 500;
                    textView29.setText("가격 : " + myFormatter.format(mTotalPrice) + "원");

                    item2.setSize(tall);
                    item2.setPrice(mTotalPrice);


                } else {
                    mTotalPrice = mTotalPrice - 500;
                    textView29.setText("가격 : " + myFormatter.format(mTotalPrice) + "원");

                    item2.setSize(tall);
                    item2.setPrice(mTotalPrice);
                }
                reference.child(item2.name).setValue(item2);
            }
        });

        checkBox6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkBox6.isChecked()) {
                    item2.setCup(cup1);
                }
                reference.child(item2.name).setValue(item2);
            }
        });

        checkBox7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkBox7.isChecked()) {
                    item2.setCup(cup2);
                }
                reference.child(item2.name).setValue(item2);
            }
        });

        checkBox8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkBox8.isChecked()) {
                    item2.setCup(cup3);
                }
                reference.child(item2.name).setValue(item2);
            }
        });

        checkBox9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkBox9.isChecked()) {
                    mTotalPrice = mTotalPrice + 1000;
                    textView29.setText("가격 : " + myFormatter.format(mTotalPrice) + "원");

                    item2.setOption2(option1);
                    item2.setPrice(mTotalPrice);

                } else {
                    mTotalPrice = mTotalPrice - 1000;
                    textView29.setText("가격 : " + myFormatter.format(mTotalPrice) + "원");

                    item2.setOption2(option1);
                    item2.setPrice(mTotalPrice);
                }
                reference.child(item2.name).setValue(item2);
            }

        });

        checkBox10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkBox10.isChecked()) {
                    mTotalPrice = mTotalPrice + 500;
                    textView29.setText("가격 : " + myFormatter.format(mTotalPrice) + "원");

                    item2.setOption2(option2);
                    item2.setPrice(mTotalPrice);

                } else {
                    mTotalPrice = mTotalPrice - 500;
                    textView29.setText("가격 : " + myFormatter.format(mTotalPrice) + "원");

                    item2.setOption2(option2);
                    item2.setPrice(mTotalPrice);

                }
                if (checkBox9.isChecked() && checkBox10.isChecked()) {
                    item2.setOption2(option4);
                }
                reference.child(item2.name).setValue(item2);
            }
        });

        checkBox11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkBox11.isChecked()) {
                    mTotalPrice = mTotalPrice + 500;
                    textView29.setText("가격 : " + myFormatter.format(mTotalPrice) + "원");

                    item2.setOption2(option3);
                    item2.setPrice(mTotalPrice);

                } else {
                    mTotalPrice = mTotalPrice - 500;
                    textView29.setText("가격 : " + myFormatter.format(mTotalPrice) + "원");

                    item2.setOption2(option3);

                    item2.setPrice(mTotalPrice);

                }
                if (checkBox9.isChecked() && checkBox11.isChecked()) {
                    item2.setOption2(option5);

                }
                if (checkBox10.isChecked() && checkBox11.isChecked()) {
                    item2.setOption2(option6);

                }
                if (checkBox9.isChecked() && checkBox10.isChecked() && checkBox11.isChecked()) {
                    item2.setOption2(option7);
                }
                reference.child(item2.name).setValue(item2);
            }
        });

        checkBox12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkBox12.isChecked()) {
                    item2.setOption3(option8);
                }
                reference.child(item2.name).setValue(item2);
            }
        });

        checkBox13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkBox13.isChecked()) {
                    item2.setOption3(option9);
                }
                reference.child(item2.name).setValue(item2);
            }
        });

        image = findViewById(R.id.imageView8);
        textView6 = findViewById(R.id.textView6);
        textView7 = findViewById(R.id.textView7);
        textView8 = findViewById(R.id.textView8);
        textView27 = findViewById(R.id.textView27);

        button10 = findViewById(R.id.button10);
        button11 = findViewById(R.id.button11);


        Intent intent = getIntent();

        image.setImageResource(intent.getIntExtra("image", 0));
        item2.setImage(String.valueOf(image));
        reference.child("image");
        String name = getIntent().getStringExtra("name");
        String eng_name = getIntent().getStringExtra("engname");
        item2.setName(name);
        item2.setEng_name(eng_name);
        reference.child("name");
        reference.child("eng_name");

        textView6.setText(name);
        textView7.setText(eng_name);
        textView8.setText(intent.getStringExtra("info"));
        textView27.setText(intent.getStringExtra("price"));
        mTotalPrice = getIntent().getIntExtra("price2", 0);
        price = getIntent().getIntExtra("price2", 0);

        button7.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                count++;
                button8.setText("" + count);

                mTotalPrice = price * count;
                textView29.setText("가격 : " + myFormatter.format(mTotalPrice) + "원");

                item2.setCount(count);
                item2.setPrice(mTotalPrice);
            }
        });


        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (count > 0) {
                    count--;
                    button8.setText("" + count);

                    mTotalPrice = price * count;
                    textView29.setText("가격 : " + myFormatter.format(mTotalPrice) + "원");

                    item2.setCount(count);
                    item2.setPrice(mTotalPrice);
                }
            }
        });

        button10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Cart.class);
                startActivity(intent);
            }
        });

        button11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), pay.class);
                startActivity(intent);
            }
        });
    }
}
