package org.techtown.afinal;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Cart extends AppCompatActivity {

    RecyclerView recyclerView;

    private DatabaseReference myRef;

    private ArrayList<Item3> item3ArrayList;

    private CartAdapter cartAdapter;
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cart);

        recyclerView = findViewById(R.id.recyclerView);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);

        myRef = FirebaseDatabase.getInstance().getReference();

        item3ArrayList = new ArrayList<>();

        ClearALL();

        GetDataFromFirebase();


    }

    private void GetDataFromFirebase() {
        Query query = myRef.child("order");
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ClearALL();
                for(DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Item3 item3 = new Item3();

                    item3.setImage(dataSnapshot.child("image").getValue().toString());
                    item3.setName(dataSnapshot.child("name").getValue().toString());
                    item3.setEng_name(dataSnapshot.child("eng_name").getValue().toString());
                    item3.setOption1(dataSnapshot.child("option1").getValue().toString());
                    item3.setCount(Integer.parseInt(dataSnapshot.child("count").getValue().toString()));
                    item3.setSize(dataSnapshot.child("size").getValue().toString());
                    item3.setCup(dataSnapshot.child("cup").getValue().toString());
                    item3.setOption2(dataSnapshot.child("option2").getValue().toString());
                    item3.setOption3(dataSnapshot.child("option3").getValue().toString());
                    item3.setPrice(Integer.parseInt(dataSnapshot.child("price").getValue().toString()));

                    item3ArrayList.add(item3);

                }
                cartAdapter = new CartAdapter(context, item3ArrayList);
                recyclerView.setAdapter(cartAdapter);
                cartAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
    private void ClearALL() {
        if(item3ArrayList != null) {
            item3ArrayList.clear();

            if(cartAdapter != null) {
                cartAdapter.notifyDataSetChanged();
            }
        }

        item3ArrayList = new ArrayList<>();

    }
}