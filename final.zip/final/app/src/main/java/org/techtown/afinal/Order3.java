package org.techtown.afinal;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DecimalFormat;

public class Order3 extends AppCompatActivity {

    ImageView image;
    TextView textView18, textView19, textView20, textView25, textView26;

    Intent intent;

    private Button button19, button20, button21;
    private int count = 0;
    public int mTotalPrice = 0;
    int price = 0;
    int i = 0;

    private CheckBox checkBox24, checkBox25, checkBox26, checkBox27;

    FirebaseDatabase database;
    DatabaseReference reference;

    Item2 item2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.order_3);

        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        reference = database.getInstance().getReference().child("order");
        item2 = new Item2();

        String option1 = "데움";
        String option2 = "데우지 않음";
        String option8 = "매장";
        String option9 = "포장";

        DecimalFormat myFormatter = new DecimalFormat("###,###");
        String formattedStringformat = myFormatter.format(mTotalPrice);

        button19 = findViewById(R.id.button19);
        button20 = findViewById(R.id.button20);
        button21 = findViewById(R.id.button21);

        textView26 = findViewById(R.id.textView26);

        checkBox24 = findViewById(R.id.checkBox24);
        checkBox25 = findViewById(R.id.checkBox25);
        checkBox26 = findViewById(R.id.checkBox26);
        checkBox27 = findViewById(R.id.checkBox27);

        checkBox24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkBox24.isChecked()) {
                    item2.setOption1(option1);
                }
                reference.child(item2.name).setValue(item2);
            }
        });

        checkBox25.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkBox25.isChecked()) {
                    item2.setOption1(option2);
                }
                reference.child(item2.name).setValue(item2);
            }
        });

        checkBox26.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkBox26.isChecked()) {
                    item2.setOption3(option8);
                }
                reference.child(item2.name).setValue(item2);
            }
        });

        checkBox27.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkBox27.isChecked()) {
                    item2.setOption3(option9);
                }
                reference.child(item2.name).setValue(item2);
            }
        });

        button19.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count++;
                button20.setText(count+"");

                mTotalPrice = price * count;
                textView26.setText("가격 : " + myFormatter.format(mTotalPrice) + "원" );

                item2.setCount(count);
                item2.setPrice(mTotalPrice);
            }
        });

        button21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(count>0) {
                    count--;
                    button20.setText(count+"");

                    mTotalPrice = price * count;
                    textView26.setText("가격 : " + myFormatter.format(mTotalPrice) + "원" );

                    item2.setCount(count);
                    item2.setPrice(mTotalPrice);
                }
            }
        });

        image = findViewById(R.id.imageView10);
        textView18 = findViewById(R.id.textView18);
        textView19 = findViewById(R.id.textView19);
        textView20 = findViewById(R.id.textView20);
        textView25 = findViewById(R.id.textView25);

        Intent intent = getIntent();

        image.setImageResource(intent.getIntExtra("image",0));
        item2.setImage(String.valueOf(image));
        reference.child("image");

        String name = getIntent().getStringExtra("name");
        String eng_name = getIntent().getStringExtra("engname");
        item2.setName(name);
        item2.setEng_name(eng_name);
        reference.child("name");
        reference.child("eng_name");

        textView18.setText(name);
        textView19.setText(eng_name);
        textView20.setText(intent.getStringExtra("info"));
        textView25.setText(intent.getStringExtra("price"));
        mTotalPrice = getIntent().getIntExtra("price2", 0);
        price = getIntent().getIntExtra("price2", 0);

    }

}
